::The Owner of this project: LoMeR-933

::There may be errors!

@echo off
color 07
title CLEANER v1.4
chcp 65001 >nul
setlocal enabledelayedexpansion
set "TotalSize=0"
set k=//Нажмите любую кнопку, чтобы перейти в меню.\\
set a=echo
set p=----------------------
set j=Добавлен
set b=ЧТО НОВОГО?
set d= - Очистить 
set m=%a% [Note: Negative MB values indicate that the folder size has exceeded the 32-bit integer limit (2 GB)]
set e=%a% [Примечание: Отрицательные значения в МБ указывают на то, что
set z=%a% размер папки превысил ограничение для 32-битных целых чисел (2 ГБ)]
set v= - Clean 
set q=//Press any button to go to the menu.\\
set f=Added
set c=-----------------------
set g=WHAT'S NEW?

:: === !RUSSIAN LANGUAGE! ===

:rus_menu
cls
%a%                                    (BY LoMeR-933)
%a%.
%a%                     * * * * * * * * * * * * * * * * * * * * * * *
%a%                     * ##### #     #####   #   #   # ##### ####  *
%a%                     * #     #     #      # #  ##  # #     #   # *
%a%                     * #     #     ###   #   # # # # ###   ####  *
%a%                     * #     #     #     ##### #  ## #     ##    *
%a%                     * ##### ##### ##### #   # #   # ##### # ##  *
%a%                     * * * * * * * * * *       * * * * * * * * * *
%a%                                       * v-1.4 *
%a%                                       * * * * *
%a%.
%a%  // ПОДСКАЗКА: Temp - это папка, в которой хранятся логи приложений и их кэш (Временные файлы) \\
%a%  // Рекомендую запускать с правами администратора \\
%a%.
%a%  » 0 - Выход
%a%  » 1%d%только пользовательский "Temp".
%a%  » 2%d%только системный "Temp".
%a%  » 3%d%ВСЕ папки "Temp".
%a%  » 4%d%корзину.
%a%  » 5 - Ускорить ОЗУ (Отключение ненужных фоновых процессов может привести к сбоям, сохраните данные^^!^^!^^!).
%a%  » 6 - Что нового?
%a%  » 7 - Switch to English/Переключиться на английский
%a%.
%a%  === РЕЖИМЫ ===
%a%  » d - Дневной режим.
%a%  » n - Ночной режим.
%a%.
set /p choice="»»» Выбери нужную тебе цифру или же букву (0-7,d,n): "

if "%choice%"=="0" exit
if "%choice%"=="1" goto us
if "%choice%"=="2" goto sy
if "%choice%"=="3" goto al
if "%choice%"=="4" goto bi
if "%choice%"=="5" goto ra
if "%choice%"=="6" goto new
if "%choice%"=="7" goto eng_menu
if "%choice%"=="d" goto da
if "%choice%"=="n" goto ni
goto rus_menu

:us
cls
%a% %p%------------
%a% Очищаем пользовательский "Temp"...
%a% %p%------------
set TotalSize=0
set MB1=0
set MB2=0
set MB3=0
set GB1=0
set GB2=0
set GB3=0
for /r "%temp%\" %%F in (*) do (
set /a "TotalSize+=%%~zF / 1048576"
del /f /q "%%F" >nul 2>&1
)
del /s /f /q "%temp%\*.*" >nul 2>&1
for /d %%p in ("%temp%\*") do rmdir /s /q "%%p" >nul 2>&1
set /a "MB1=TotalSize"
set /a "GB1=MB1 / 1024"
%a%.
%a% Пользовательская папка "Temp" очищена^^!
%a%.
%a% Всего найдено: %MB1% MB (~%GB1% GB).
set TotalSize=0
for /r "%temp%\" %%F in (*) do (
set /a "TotalSize+=%%~zF / 1048576"
)
set /a "MB2=TotalSize"
set /a "GB2=MB2 / 1024"
%a% Сейчас там: %MB2% MB (~%GB2% GB).
set /a "MB3=MB1 - MB2"
set /a "GB3=GB1 - GB2"
%a% Удалено: %MB3% MB (~%GB3% GB).
%a%.
%e%
%z%
%a%.
%a% %k%
pause >nul
goto rus_menu


:sy
cls
%a% %p%-----
%a% Очищаем системный "Temp"...
%a% %p%-----
set TotalSize=0
set MB1=0
set MB2=0
set MB3=0
set GB1=0
set GB2=0
set GB3=0
for /r "%systemroot%\Temp" %%F in (*) do (
set /a "TotalSize+=%%~zF / 1048576"
del /f /q "%%F" >nul 2>&1
)
del /s /f /q "%systemroot%\Temp\*.*" >nul 2>&1
for /d %%p in ("%systemroot%\Temp\*") do rmdir /s /q "%%p" >nul 2>&1
set /a "MB1=TotalSize"
set /a "GB1=MB1 / 1024"
%a%.
%a% Системная папка "Temp" очищена^^!
%a%.
%a% Всего найдено: %MB1% MB (~%GB1% GB).
set TotalSize=0
for /r "%systemroot%\Temp" %%F in (*) do (
set /a "TotalSize+=%%~zF / 1048576"
)
set /a "MB2=TotalSize"
set /a "GB2=MB2 / 1024"
%a% Сейчас там: %MB2% MB (~%GB2% GB).
set /a "MB3=MB1 - MB2"
set /a "GB3=GB1 - GB2"
%a% Удалено: %MB3% MB (~%GB3% GB).
%a%.
%e%
%z%
%a%.
%a% %k%
pause >nul
goto rus_menu


:al
cls
%a% %p%-----
%a% Очищаем все папки "Temp"...
%a% %p%-----
set TotalSize=0
set MB1=0
set MB2=0
set MB3=0
set GB1=0
set GB2=0
set GB3=0
for /r "%temp%\" %%F in (*) do (
set /a "TotalSize+=%%~zF / 1048576"
del /f /q "%%F" >nul 2>&1
)
for /r "%systemroot%\Temp" %%F in (*) do (
set /a "TotalSize+=%%~zF / 1048576"
del /f /q "%%F" >nul 2>&1
)
del /s /f /q "%temp%\*.*" >nul 2>&1
for /d %%p in ("%temp%\*") do rmdir /s /q "%%p" >nul 2>&1
del /s /f /q "%systemroot%\Temp\*.*" >nul 2>&1
for /d %%p in ("%systemroot%\Temp\*") do rmdir /s /q "%%p" >nul 2>&1
set /a "MB1=TotalSize"
set /a "GB1=MB1 / 1024"
%a%.
%a% Полная очистка завершена^^!
%a%.
%a% Всего найдено: %MB1% MB (~%GB1% GB).
set TotalSize=0
for /r "%temp%\" %%F in (*) do (
set /a "TotalSize+=%%~zF / 1048576"
)
for /r "%systemroot%\Temp" %%F in (*) do (
set /a "TotalSize+=%%~zF / 1048576"
)
set /a "MB2=TotalSize"
set /a "GB2=MB2 / 1024"
%a% Сейчас там: %MB2% MB (~%GB2% GB).
set /a "MB3=MB1 - MB2"
set /a "GB3=GB1 - GB2"
%a% Удалено: %MB3% MB (~%GB3% GB).
%a%.
%e%
%z%
%a%.
%a% %k%
pause >nul
goto rus_menu


:bi
rd /s /q %systemdrive%\$Recycle.Bin
cls
%a% %c%
%a%  Корзина была очищена^^!
%a% %c%
%a%.
%a% %k%
pause >nul
goto rus_menu

:new
cls
%a% %p%
%a% ===  %b%  ===
%a% === ВЕРСИЯ "v_1.1" ===
%a% %p%
%a%.
%a% 1. %j% новый цвет фона и текста.
%a% 2. %j% совет.
%a% 3. %j%а утилита "Что нового?"
%a% 4. Исправлены ошибки в тексте и коде.
%a%.
%a% %p%
%a% ===  %b%   ===
%a% === ВЕРСИЯ "v_1.2" ===
%a% %p%
%a%.
%a% 1. %j%а утилита "Очистить корзину". Теперь чистится не только "Temp"^^! :D
%a% 2. Изменены название и дизайн, в том числе название в меню.
%a% 3. Вместо классики "Press any key to continue..." поставлено новое:
%a% "%k%"^^! :D
%a% 4. %j%а подсказка в меню.
%a% 5. %j%ы режимы.
%a%.
%a% %p%
%a% ===  %b%   ===
%a% === ВЕРСИЯ "v_1.3" ===
%a% %p%
%a%.
%a% 1. %j%а утилита "Ускорить ОЗУ". Оперативная память вздохнет свежим воздухом^^! :D
%a% (отключение процессов может привести к сбоям!)
%a% 2. Изменён интерфейс и расположение.
%a% 3. Оптимизирован код, теперь сам bat весит примерно на ~0.85 КБ меньше^^!
%a% 4. Добавлен баннер в меню из "#"^^! Теперь меню выглядит намного красивее^^! :D
%a% 5. Добавлен английский язык^^!
%a%.
%a% %p%
%a% ===  %b%   ===
%a% ===ВЕРСИЯ "v_1.3.1"===
%a% %p%
%a%.
%a% 1. Исправлены многочисленные ошибки в коде.
%a%.
%a% %p%
%a% ===  %b%   ===
%a% === ВЕРСИЯ "v_1.4" ===
%a% %p%
%a%.
%a% 1. Исправлены многочисленные ошибки в коде и тексте.
%a% 2. %j% счетчик памяти^^!
%a% 3. Теперь изначально стоит ночной режим, чтобы не слепить пользователей^^! :D
%a% 4. Совет был удален.
%a% 5. Арт "CLEANER" пододвинул примерно до центра и рядом поставил версию^^! :D
%a%.
%a% Оригинальный вес файла составляет: ~15-16 КБ.
%a%.
%a% %k%
pause >nul
goto rus_menu

:ni
cls
%a% Включаем ночной режим...
color 07
timeout /t 1 >nul
goto rus_menu

:da
cls
%a% Включаем дневной режим...
color 9E
timeout /t 1 >nul
goto rus_menu

:ra
cls
%a%.
%a% » Очищаем оперативную память (ОЗУ)...
taskkill /f /fi "status eq not responding" >nul
taskkill /f /im explorer.exe >nul 2>&1
start explorer.exe
%a%.
%a% » ОЗУ была очищена от лишних фоновых процессов.
%a%  Вы могли увидеть, как рабочий стол смог исчезнуть^^!
%a%.
%a% %k%
pause >nul
goto rus_menu

:: === !ENGLISH LANGUAGE! ===

:eng_menu
cls
%a%                                    (BY LoMeR-933)
%a%.
%a%                     * * * * * * * * * * * * * * * * * * * * * * *
%a%                     * ##### #     #####   #   #   # ##### ####  *
%a%                     * #     #     #      # #  ##  # #     #   # *
%a%                     * #     #     ###   #   # # # # ###   ####  *
%a%                     * #     #     #     ##### #  ## #     ##    *
%a%                     * ##### ##### ##### #   # #   # ##### # ##  *
%a%                     * * * * * * * * * *       * * * * * * * * * *
%a%                                       * v-1.4 *
%a%                                       * * * * *
%a%.
%a%  // HINT: Temp is the folder where application logs and caches (Temporary files) are stored \\
%a%  // I recommend running it with administrator rights \\
%a%  // WARNING: The translation may not be exact^^!
%a%.
%a%  » 0 - Exit
%a%  » 1%v%User "Temp" only.
%a%  » 2%v%System "Temp" only.
%a%  » 3%v%ALL "Temp" folders.
%a%  » 4 - Empty Recycle Bin.
%a%  » 5 - Optimize RAM (Disabling unnecessary background processes may cause crashes, save your data^^!^^!^^!).
%a%  » 6 - What's new?
%a%  » 7 - Switch to Russian/Переключиться на русский
%a%.
%a%  === MODES ===
%a%  » d - Day mode.
%a%  » n - Night mode.
%a%.
set /p choice="»»» Select the number or letter you need (0-7,d,n): "

if "%choice%"=="0" exit
if "%choice%"=="1" goto u
if "%choice%"=="2" goto s
if "%choice%"=="3" goto a
if "%choice%"=="4" goto b
if "%choice%"=="5" goto r
if "%choice%"=="6" goto ne
if "%choice%"=="7" goto rus_menu
if "%choice%"=="d" goto d
if "%choice%"=="n" goto n
goto eng_menu

:n
cls
%a% Turning on night mode...
color 07
timeout /t 1 >nul
goto eng_menu

:d
cls
%a% Turning on day mode...
color 9E
timeout /t 1 >nul
goto eng_menu

:r
cls
%a%.
%a% » Cleaning up RAM...
taskkill /f /fi "status eq not responding" >nul
taskkill /f /im explorer.exe >nul 2>&1
start explorer.exe
%a%.

%a% » RAM cleared of unnecessary background processes.
%a% You may have noticed the desktop has disappeared^^!

%a%.
%a% %q%
pause >nul
goto eng_menu

:ne
cls
%a% %c%
%a% ===   %g%   ===
%a% === VERSION "v_1.1" ===
%a% %c%
%a%.
%a% 1. %f% new background and text color.
%a% 2. %f% tooltip.
%a% 3. %f% "What's New?" utility.
%a% 4. Fixed errors in text and code.
%a%.
%a% %c%
%a% ===   %g%   ===
%a% === VERSION "v_1.2" ===
%a% %c%
%a%.
%a% 1. %f% "Empty Trash" utility. Now it cleans more than just "Temp"^^! :D
%a% 2. Changed name and design, including the menu title. 
%a% 3. The classic "Press any key to continue..." phrase has been replaced with a new one:
%a% "%q%"^^! :D
%a% 4. %f% hint to the menu.
%a% 5. %f% modes.
%a%.
%a% %c%
%a% ===   %g%   ===
%a% === VERSION "v_1.3" ===
%a% %c%
%a%.
%a% 1. %f% "Clean RAM" utility. Your RAM will get a breath of fresh air^^! :D
%a% 2. The interface and layout of elements have been changed.
%a% 3. The code has been optimized; the bat file itself is now approximately ~0.85 KB smaller^^!
%a% 4. A banner of "#" has been added to the menu! Now the menu looks much prettier^^! :D
%a%.
%a% %c%
%a% ===   %g%   ===
%a% ===VERSION "v_1.3.1"===
%a% %c%
%a%.
%a% 1. Numerous bugs have been fixed.
%a%.
%a% %c%
%a% ===   %g%   ===
%a% === VERSION "v_1.4" ===
%a% %c%
%a%.
%a% 1. Fixed numerous code and text errors.
%a% 2. %f% memory counter^^!
%a% 3. Night mode is now enabled by default to avoid blinding users^^! :D
%a% 4. Tooltip removed.
%a% 5. The window size is now fixed at 130x40 for a better view^^!
%a% 6. Centered the "CLEANER" art and added the version tag^^! :D
%a%.
%a% %a% Original file size: ~15-16 KB.
%a%.
%a% %q%
pause >nul
goto eng_menu

:b
cls
rd /s /q %systemdrive%\$Recycle.bin
%a%.
cls
%a% %c%---------
%a% The recycle bin has been emptied!
%a% %c%---------
%a%.
%a% %q%
pause >nul
goto eng_menu

:a
cls
set TotalSize=0
%a% %c%-------
%a% Clearing all "Temp" folders...
%a% %c%-------
for /r "%temp%\" %%F in (*) do set /a "TotalSize+=%%~zF/1048576"
for /r "%systemroot%\Temp\" %%F in (*) do set /a "TotalSize+=%%~zF/1048576"
set /a "MB1=TotalSize"
set /a "GB1=MB1/1024"
del /s /f /q "%temp%\*.*" >nul 2>&1
for /d %%p in ("%temp%\*") do rmdir /s /q "%%p" >nul 2>&1
del /s /f /q "%systemroot%\Temp\*.*" >nul 2>&1
for /d %%p in ("%systemroot%\Temp\*") do rmdir /s /q "%%p" >nul 2>&1
%a%.
%a% Full cleanup complete^^!
%a%.
%a% Total found: %MB1% MB (~%GB1% GB).
set TotalSize=0
for /r "%temp%\" %%F in (*) do set /a "TotalSize+=%%~zF/1048576"
for /r "%systemroot%\Temp\" %%F in (*) do set /a "TotalSize+=%%~zF/1048576"
set /a "MB2=TotalSize"
set /a "GB2=MB2/1024"
%a% Currently there: %MB2% MB (~%GB2% GB).
set /a "MB3=MB1-MB2"
set /a "GB3=MB3/1024"
%a% Deleted: %MB3% MB (~%GB3% GB).
%a%.
%m%
%a%.
%a% %q%
pause >nul
goto eng_menu

:s
cls
set TotalSize=0
%a% %c%------
%a% Clearing the system "Temp"...
%a% %c%------
for /r "%systemroot%\Temp\" %%F in (*) do set /a "TotalSize+=%%~zF/1048576"
set /a MB1=TotalSize
set /a GB1=MB1/1024
del /s /f /q "%systemroot%\Temp\*.*" >nul 2>&1
for /d %%p in ("%systemroot%\Temp\*") do rmdir /s /q "%%p" >nul 2>&1
%a%.
%a% The system "Temp" folder has been cleared^^!
%a%.
%a% Total found: %MB1% MB (%GB1% GB).
set TotalSize=0
for /r "%systemroot%\Temp\" %%F in (*) do set /a "TotalSize+=%%~zF/1048576"
set /a MB2=TotalSize
set /a GB2=MB2/1024
%a% Currently there: %MB2% MB (%GB2% GB).
set /a MB3=MB1-MB2
set /a GB3=MB3/1024
%a% Deleted: %MB3% MB (%GB3% GB).
%a%.
%m%
%a%.
%a% %q%
pause >nul
goto eng_menu


:u
cls
set TotalSize=0
%a% %c%
%a%  Clearing user Temp...
%a% %c%
for /r "%temp%\" %%F in (*) do set /a "TotalSize+=%%~zF/1048576"
set /a MB1=TotalSize
set /a GB1=MB1/1024
del /s /f /q "%temp%\*.*" >nul 2>&1
for /d %%p in ("%temp%\*") do rmdir /s /q "%%p" >nul 2>&1
%a%.
%a% User "Temp" folder cleared^^!
%a%.
%a% Total found: %MB1% MB (%GB1% GB).
set TotalSize=0
for /r "%temp%\" %%F in (*) do set /a "TotalSize+=%%~zF/1048576"
set /a MB2=TotalSize
set /a GB2=MB2/1024
%a% Currently there: %MB2% MB (%GB2% GB).
set /a MB3=MB1-MB2
set /a GB3=MB3/1024
%a% Deleted: %MB3% MB (%GB3% GB).
%a%.
%m%
%a%.
%a% %q%
pause >nul
goto eng_menu
