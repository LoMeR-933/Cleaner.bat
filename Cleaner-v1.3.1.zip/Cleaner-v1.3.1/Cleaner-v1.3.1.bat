::The Owner of this project: LoMeR-933

::There may be errors!

color 9E
@echo off
title CLEANER V 1.3 (BY LoMeR-933)
chcp 65001 >nul
set k=//Нажмите любую кнопку, чтобы перейти в меню.\\
set l=СОВЕТ: Если видишь, что где-то пишет "Access is denied", неважно, возможно этот файл сейчас используется.
set a=echo
set p=----------------------
set j=Добавлен
set b=ЧТО НОВОГО?
set d= - Очистить 
set v= - Clean 
set q=//Press any button to go to the menu.\\
set f=Added
set r=TIP: If you see "Access is denied" written somewhere, it doesn't matter, the file may be in use right now.
set c=-----------------------
set g=WHAT'S NEW?

:: === !RUSSIAN LANGUAGE! ===

:rus_menu
cls
%a%.
%a%  * * * * * * * * * * * * * * * * * * * * * * *
%a%  * ##### #     #####   #   #   # ##### ####  *
%a%  * #     #     #      # #  ##  # #     #   # *
%a%  * #     #     ###   #   # # # # ###   ####  *
%a%  * #     #     #     ##### #  ## #     ##    *
%a%  * ##### ##### ##### #   # #   # ##### # ##  *
%a%  * * * * * * * * * * * * * * * * * * * * * * *
%a%.
%a%  // ПОДСКАЗКА: Temp - это папка, в которой хранятся логи приложений и их кэш (Временный мусор) \\
%a%  // Рекомендую запускать с правами администратора \\
%a%.
%a%  » 0 - Выход
%a%  » 1%d%только пользовательский "Temp".
%a%  » 2%d%только системный "Temp".
%a%  » 3%d%ВСЕ папки "Temp".
%a%  » 4%d%корзину.
%a%  » 5 - Ускорить ОЗУ (Отключение ненужных фоновых процессов, рабочий стол может заглючить на 1 сек!).
%a%  » 6 - Что нового?
%a%  » 7 - Switch to English/Переключиться на английский
%a%.
%a%  === РЕЖИМЫ ===
%a%  » d - Дневной режим.
%a%  » n - Ночной режим.
%a%.
set /p choice="»»» Выбери нужную тебе цифру или же букву (0-7,d,n): "

if "%choice%"=="0" exit
if "%choice%"=="1" goto us
if "%choice%"=="2" goto sy
if "%choice%"=="3" goto al
if "%choice%"=="4" goto bi
if "%choice%"=="5" goto ra
if "%choice%"=="6" goto new
if "%choice%"=="7" goto eng_menu
if "%choice%"=="d" goto da
if "%choice%"=="n" goto ni
goto rus_menu

:us
cls
%a% Очищаем пользовательский "Temp"...
del /s /f /q "%temp%\*.*"
for /d %%p in ("%temp%\*") do rmdir /s /q "%%p"
%a% Пользовательская папка "Temp" очищена!
%a%.
%a% %l%
%a%.
%a% %k%
pause >nul
goto rus_menu

:sy
cls
%a% Очищаем системный "Temp"...
del /s /f /q "%systemroot%\Temp\*.*"
for /d %%p in ("%systemroot%\Temp\*") do rmdir /s /q "%%p"
%a% Системная папка "Temp" очищена!
%a%.
%a% %l%
%a%.
%a% %k%
pause >nul
goto rus_menu

:al
cls
%a% Очищаем все папки "Temp"...
del /s /f /q "%temp%\*.*"
for /d %%p in ("%temp%\*") do rmdir /s /q "%%p"
del /s /f /q "%systemroot%\Temp\*.*"
for /d %%p in ("%systemroot%\Temp\*") do rmdir /s /q "%%p"
%a% Полная очистка завершена!
%a%.
%a% %l%
%a%.
%a% %k%
pause >nul
goto rus_menu

:bi
cls
rd /s /q %systemdrive%\$Recycle.bin
%a%.
%a% Корзина была очищена!
%a%.
%a% %k%
pause >nul
goto rus_menu

:new
cls
%a% %p%
%a% ===  %b%  ===
%a% === ВЕРСИЯ "v_1.1" ===
%a% %p%
%a%.
%a% 1. %j% новый цвет фона и текста.
%a% 2. %j% совет.
%a% 3. %j%а утилита "Что нового?"
%a% 4. Исправлены ошибки в тексте и коде.
%a%.
%a% %p%
%a% ===  %b%   ===
%a% === ВЕРСИЯ "v_1.2" ===
%a% %p%
%a%.
%a% 1. %j%а утилита "Очистить корзину". Теперь чистится не только "Temp"! :D
%a% 2. Изменены название и дизайн, в том числе название в меню.
%a% 3. Вместо классики "Press any key to continue..." поставлено новое:
%a% "%k%"! :D
%a% 4. %j%а подсказка в меню.
%a% 5. %j%ы режимы.
%a%.
%a% %p%
%a% ===  %b%   ===
%a% === ВЕРСИЯ "v_1.3" ===
%a% %p%
%a%.
%a% 1. %j%а утилита "Ускорить ОЗУ". Оперативная память вздохнет свежим воздухом! :D
%a% 2. Изменён интерфейс и расположение.
%a% 3. Оптимизирован код, теперь сам bat весит примерно на ~0.85 КБ меньше!
%a% 4. Добавлен баннер в меню из "#"! Теперь меню выглядит намного красивее! :D
%a% 5. Добавлен английский язык!
%a%.
%a% ===  %b%   ===
%a% === ВЕРСИЯ "v_1.3.1" ===
%a%.
%a% 1. Исправлены многочисленные ошибки.
%a%.
%a% %k%
pause >nul
goto rus_menu

:ni
cls
%a% Включаем ночной режим...
color 07
timeout /t 1 >nul
goto rus_menu

:da
cls
%a% Включаем дневной режим...
color 9E
timeout /t 1 >nul
goto rus_menu

:ra
cls
%a%.
%a% » Очищаем оперативную память (ОЗУ)...
taskkill /f /fi "status eq not responding" >nul
taskkill /f /im explorer.exe >nul 2>&1
start explorer.exe
%a%.
%a% » ОЗУ была очищена от лишних фоновых процессов.
%a%  Вы могли увидеть, как рабочий стол смог исчезнуть!
%a%.
%a% %k%
pause >nul
goto rus_menu

:: === !ENGLISH LANGUAGE! ===

:eng_menu
cls
%a%.
%a%  * * * * * * * * * * * * * * * * * * * * * * *
%a%  * ##### #     #####   #   #   # ##### ####  *
%a%  * #     #     #      # #  ##  # #     #   # *
%a%  * #     #     ###   #   # # # # ###   ####  *
%a%  * #     #     #     ##### #  ## #     ##    *
%a%  * ##### ##### ##### #   # #   # ##### # ##  *
%a%  * * * * * * * * * * * * * * * * * * * * * * *
%a%.
%a%  // HINT: Temp is the folder where application logs and caches (Temporary Junk) are stored \\
%a%  // I recommend running it with administrator rights \\
%a%  // WARNING: The translation may not be exact!
%a%.
%a%  » 0 - Exit
%a%  » 1%v%User "Temp" only.
%a%  » 2%v%System "Temp" only.
%a%  » 3%v%ALL "Temp" folders.
%a%  » 4%v%Recycle Bin.
%a%  » 5%v%RAM (Disables unnecessary background processes, the desktop may freeze for 1 second!).
%a%  » 6 - What's new?
%a%  » 7 - Switch to Russian/Переключиться на русский
%a%.
%a%  === MODES ===
%a%  » d - Day mode.
%a%  » n - Night mode.
%a%.
set /p choice="»»» Select the number or letter you need (0-7,d,n): "

if "%choice%"=="0" exit
if "%choice%"=="1" goto u
if "%choice%"=="2" goto s
if "%choice%"=="3" goto a
if "%choice%"=="4" goto b
if "%choice%"=="5" goto r
if "%choice%"=="6" goto ne
if "%choice%"=="7" goto rus_menu
if "%choice%"=="d" goto d
if "%choice%"=="n" goto n
goto eng_menu

:n
cls
%a% Turning on night mode...
color 07
timeout /t 1 >nul
goto eng_menu

:d
cls
%a% Turning on day mode...
color 9E
timeout /t 1 >nul
goto eng_menu

:r
cls
%a%.
%a% » Cleaning up RAM...
taskkill /f /fi "status eq not responding" >nul
taskkill /f /im explorer.exe >nul 2>&1
start explorer.exe
%a%.

%a% » RAM cleared of unnecessary background processes.
%a% You may have noticed the desktop has disappeared!

%a%.
%a% %q%
pause >nul
goto eng_menu

:ne
cls
%a% %c%
%a% ===   %g%   ===
%a% === VERSION "v_1.1" ===
%a% %c%
%a%.
%a% 1. New background and text color.
%a% 2. Tooltip.
%a% 3. "What's New?" utility
%a% 4. Fixed errors in text and code.
%a%.
%a% %c%
%a% ===   %g%   ===
%a% === VERSION "v_1.2" ===
%a% %c%
%a%.
%a% 1. %f% "Empty Trash" utility. Now it cleans more than just "Temp"! :D
%a% 2. Changed name and design, including the menu title. %a% 3. The classic "Press any key to continue..." phrase has been replaced with a new one:
%a% "%q%"! :D
%a% 4. %f% hint to the menu.
%a% 5. %f% modes.
%a%.
%a% %c%
%a% ===   %g%   ===
%a% === VERSION "v_1.3" ===
%a% %c%
%a%.
%a% 1. %f% "Clean RAM" utility. Your RAM will get a breath of fresh air! :D
%a% 2. The interface and layout of elements have been changed.
%a% 3. The code has been optimized; the bat file itself is now approximately ~0.85 KB smaller!
%a% 4. A banner of "#" has been added to the menu! Now the menu looks much prettier! :D
%a%.
%a% ===   %g%   ===
%a% === VERSION "v_1.3.1" ===
%a%.
%a% 1. Numerous bugs have been fixed.
%a%.
%a% %q%
pause >nul
goto eng_menu

:b
cls
rd /s /q %systemdrive%\$Recycle.bin
%a%.
%a% The recycle bin has been emptied!
%a%.
%a% %q%
pause >nul
goto eng_menu

:a
cls
%a% Clearing all "Temp" folders...
del /s /f /q "%temp%\*.*"
for /d %%p in ("%temp%\*") do rmdir /s /q "%%p"
del /s /f /q "%systemroot%\Temp\*.*"
for /d %%p in ("%systemroot%\Temp\*") do rmdir /s /q "%%p"
%a% Full cleanup complete!
%a%.
%a% %r%
%a%.
%a% %q%
pause >nul
goto eng_menu

:s
cls
%a% Clearing the system "Temp"...
del /s /f /q "%systemroot%\Temp\*.*"
for /d %%p in ("%systemroot%\Temp\*") do rmdir /s /q "%%p"
%a% The system "Temp" folder has been cleared!
%a%.
%a% %r%
%a%.
%a% %q%
pause >nul
goto eng_menu

:u
cls
%a% Clearing user Temp...
del /s /f /q "%temp%\*.*"
for /d %%p in ("%temp%\*") do rmdir /s /q "%%p"
%a% User "Temp" folder cleared!
%a%.
%a% %r%
%a%.
%a% %q%
pause >nul
goto eng_menu